

#ifndef _HELPING_H_
#define _HELPING_H_

#include "Application.h"
#include <stdio.h>

void printCard(ST_cardData_t *card);

void printTerminal(ST_terminalData_t *terminal);

void printServerTransaction(ST_transaction_t *card);

uint32_t seq_generator(void);
uint8_t datasearch(uint8_t *card);

#endif // _HELPING_H_


