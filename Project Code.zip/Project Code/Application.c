#include <stdio.h>
#include "Application.h"

ST_cardData_t Card_data[10]={{"ahmed alaa el-Sheikh"   ,"10/22", "799273987130000000"},
                            {"MOHAMED ALAA EL-DIN ABD" ,"07/23", "799273987130202060"},
                            {"OMNIA ALAA EL-DIN ABD"   ,"10/22", "799273987130602020"},
                            {"OMAR ALAA EL-DIN ABD"    ,"10/21", "729973987130602020"},
                            {"ALII ALAA EL-DIN ABD"    ,"10/22", "799273789130602020"},
                            {"SARA ALAA EL-DIN ABD"    ,"10/22", "799372987031602021"},
                            {"SAHAR ALAA EL-DIN ABD"   ,"10/22", "997273987130602020"},
                            {"SAHER ALAA EL-aaaaaaD"   ,"01/22", "797293987130602020"},
                            {"ALAA ALAA EL-DIN ABD"    ,"03/22", "799273789130602020"},
                            {"SAMAR ALAA EL-DIN ABD"   ,"10/22", "799273983170602020"},
                            };
ST_terminalData_t terminal[10]={0};
ST_transaction_t server[10]={0};

static uint8_t terminal_index=0;
static uint8_t Card_data_index=0;
static uint8_t server_index=0;

void appStart(void)
{

    EN_cardError_t Card_status[3]={0};

    printf("----------------------- CARD MODULE--------------------------------\n");

    Card_status[0]=getCardHolderName(&Card_data[Card_data_index]);
    Card_status[1]=getCardExpiryDate(&Card_data[Card_data_index]);
    Card_status[2]=getCardPAN(&Card_data[Card_data_index]);

    if(!Card_status[0] || !Card_status[1] || !Card_status[2])   //-- INITIAL CHECK FOR THE CARD DATA --//
    {
        printCard(&Card_data[Card_data_index]);
        printf("\n-------------------------------------------------------------------\n");

        printf("\n----------------------- TERMINAL MODULE----------------------------\n");

        EN_terminalError_t Terminal_status[6]={0};

        Terminal_status[0] = getTransactionDate(&terminal[terminal_index]);
        Terminal_status[1] = isCardExpired(&Card_data[Card_data_index],&terminal[terminal_index]);
        Terminal_status[2] = isValidCardPAN(&Card_data[Card_data_index]);



        if(Terminal_status[2])                                  //-- CHECK FOR CARD VALIDATION --//
        {
            printf("\n-------------------------------------------------------------------");
            printf("\n\tYOUR CARD IS NOT VALID\n");
            printf("-------------------------------------------------------------------\n");
        }

        else if(Terminal_status[1])                           //-- CHECK FOR CARD EXPIARY DATE --//
        {
            printf("\n-------------------------------------------------------------------");
            printf("\n\tYOUR CARD IS EXPIRED\n");
            printf("-------------------------------------------------------------------\n");
        }

        else
        {
            Terminal_status[3] = setMaxAmount(&terminal[terminal_index]);
            Terminal_status[4] = getTransactionAmount(&terminal[terminal_index]);
            Terminal_status[5] = isBelowMaxAmount(&terminal[terminal_index]);
            if(Terminal_status[5])              //-- CHECK FOR THE TRANSACTION AMOUNT IF EXCEED THE MAXIMUM AMOUNT --//
            {
                printf("\n-------------------------------------------------------------------");
                printf("\n\tSORRY YOU EXCEEDED THE MAX TRANSACTION AMOUNT\n");
                printf("-------------------------------------------------------------------\n");
            }
            else
            {
                printTerminal(&terminal[terminal_index]);
                printf("\n-------------------------------------------------------------------\n");

                printf("\n------------------------- SERVER MODULE----------------------------\n");
                EN_transState_t server_status[2]={0};

                server[server_index].cardHolderData=Card_data[Card_data_index];
                server[server_index].terminalData=terminal[terminal_index];
                server[server_index].transState=ServerAccounts[datasearch(Card_data[Card_data_index].primaryAccountNumber)-1].state;
                server[server_index].transactionSequenceNumber=0;

                server_status[0]=recieveTransactionData(&server[server_index]);
                if(server_status[0]==DECLINED_STOLEN_CARD || server_status[0] == FRAUD_CARD)   //-- CHECK FOR PAN NUMBER AND STATE OF THE CARD --//
                {
                    printf("\n-------------------------------------------------------------------");
                    printf("\n\tTHIS CARD IS NOT VALID OR BLOCKED\n");
                    printf("-------------------------------------------------------------------\n");
                }
               else if(server_status[0] == DECLINED_INSUFFECIENT_FUND)                         //-- CHECK IF THERE IS SUFFECIENT FUND FOR THE TRANSACION --//
                {
                   printf("-------------------------------------------------------------------\n");
                   printf("\tDECLINED_INSUFFECIENT_FUND\n");
                   printf("-------------------------------------------------------------------\n");
                }
                else if(server_status[0]== INTERNAL_SERVER_ERROR)                              //-- CHECK FOR SAVING TRANSACION PROCESS --//
                {
                   printf("\n-------------------------------------------------------------------");
                   printf("\n\tSERVER ERROR WHILE SAVING\n");
                   printf("-------------------------------------------------------------------\n");
                }
                else
                {
                   printf("\n-------------------------------------------------------------------");
                   printf("\n|                  TRANSACTION APPROVED                           |\n");
                   printf("-------------------------------------------------------------------\n");
                   server_status[1]=saveTransaction(&server[server_index]);
                   !server_status[1]? printServerTransaction(&server[server_index]) : printf("SERVER ERROR");

                }

          }
       }
        terminal_index++;
        Card_data_index++;
    }

    else
    {
        printf("\n\t\tCARD NOT FOUND");
    }
}

