#include "Helping_file.h"
void printCard(ST_cardData_t *card)
{
    printf("\nCard Holder Name : ");
    printf("%s\n",(card->cardHolderName));

    printf("Card EXPIRY Date : ");
    printf("%s\n",card->cardExpirationDate);

    printf("Card ACC NUMBER  : ");
    printf("%s\n",card->primaryAccountNumber);
}

void printTerminal(ST_terminalData_t *terminal)
{
    printf("\nTransaction Date : %s",terminal->transactionDate);

    printf("\nMAX Trans Amount : %.2f",terminal->maxTransAmount);

    printf("\nYour Amount      : %.2f",terminal->transAmount);
}

void printServerTransaction(ST_transaction_t *card)
{
    printCard(&(card->cardHolderData));
    printTerminal(&(card->terminalData));
    printf("\n\nTransaction state           : %d",card->transState);
    printf("\nTransaction Sequence Number : %d\n\n",card->transactionSequenceNumber);
}

uint32_t seq_generator(void)
{

    uint32_t LOW=0;
    uint32_t HIGH =0xffff;

    static uint32_t randomNumber;
    randomNumber = rand() % (HIGH - LOW + 1) + LOW;
    for(int i=0;i<255;i++)
    {
       while(serverTransactions[i].transactionSequenceNumber == randomNumber)
       {
         randomNumber = rand() % (HIGH - LOW + 1) + LOW;
       }
    }
    return randomNumber;
}

static int check_str(uint8_t *arr1,uint8_t*arr2)
{
    for(int i=0;i<20;i++)
    {
        if(arr1[i]!=arr2[i])
        {
            return 1;
        }
    }
    return 0;
}


uint8_t datasearch(uint8_t *card)
{
    for(int i=0; i<255; i++)
    {
        if(!check_str(card,ServerAccounts[i].primaryAccountNumber))
        {
            return i+1;
        }
    }
return 0;
}

