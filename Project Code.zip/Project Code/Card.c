#include<stdio.h>
#include "Card.h"
#include <string.h>
EN_cardError_t getCardHolderName(ST_cardData_t* cardData)
{
	if (cardData->cardHolderName == NULL || strlen((const char*)(cardData->cardHolderName)) < 20 || strlen((const char*)(cardData->cardHolderName)) > 24)
	{
        return WRONG_NAME;
	}
    for(int i=0;cardData->cardHolderName[i];i++)  //-- CHECK THAT THERE IS NO NUMBERS IN THE STRING --//
      {
        if(cardData->cardHolderName[i] >='0' && cardData->cardHolderName[i] <='9')
        {
            return WRONG_NAME;
        }
      }
	return OK;
}
EN_cardError_t getCardExpiryDate(ST_cardData_t* cardData)  // "MM/YY"
{

    // CHECK FOR FORMATE
    if (cardData->cardExpirationDate == NULL || strlen((const char*)(cardData->cardExpirationDate)) != 5 || cardData->cardExpirationDate[2] != '/')
    {
        printf("\n\t\tWRONG EXP DATE\n");
        return WRONG_EXP_DATE;
    }

    // CHECK FOR MONTH LOGIC
    if (cardData->cardExpirationDate[0] > '2' || cardData->cardExpirationDate[0] < '0' || cardData->cardExpirationDate[1] < '0')
    {
        printf("\n\t\tWRONG EXP DATE\n");
        return WRONG_EXP_DATE;
    }

    if (cardData->cardExpirationDate[0] == '0')
    {
        if (cardData->cardExpirationDate[1] > '9' || cardData->cardExpirationDate[1] < '1')
        {
           printf("\n\t\tWRONG EXP DATE\n");
           return WRONG_EXP_DATE;
        }
    }

    if (cardData->cardExpirationDate[0] == '1')
    {
        if (cardData->cardExpirationDate[1] > '2')
        {
          printf("\n\t\tWRONG EXP DATE\n");
          return WRONG_EXP_DATE;
        }
    }

    // CHECK FOR YEAR LOGIC
    if (/*(cardData->cardExpirationDate[3] == '0' && cardData->cardExpirationDate[4] == '0') ||*/ (cardData->cardExpirationDate[3] < '0' || cardData->cardExpirationDate[4] < '0'|| cardData->cardExpirationDate[4] > '9' || cardData->cardExpirationDate[3] > '9'))
    {
        printf("\n\t\tWRONG EXP DATE\n");
        return WRONG_EXP_DATE;
    }

    return OK;
}
EN_cardError_t getCardPAN(ST_cardData_t* cardData)
{
	if ( strlen((const char*)(cardData->primaryAccountNumber))< 16 || strlen((const char*)(cardData->primaryAccountNumber)) > 19 || cardData->primaryAccountNumber == NULL)
	{
		printf("\n\t\tWRONG PAN NUMBER\n");
		return WRONG_PAN;
	}
	for(uint8_t i=0;cardData->primaryAccountNumber[i];i++)
    {
        if(cardData->primaryAccountNumber[i] < '0' || cardData->primaryAccountNumber[i] > '9')
        {
		   printf("\n\t\tWRONG PAN NUMBER\n");
		   return WRONG_PAN;
        }
    }
	return OK;
}


