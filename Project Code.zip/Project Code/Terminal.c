
#include "Terminal.h"
#include <stdio.h>
#include<stdlib.h>
#include <time.h>



/// tm.tm_mday, tm.tm_mon + 1,tm.tm_year + 1900

static void real_time_str(uint8_t *arr)
{
    time_t t=time(NULL);
    struct tm tm =tm=*localtime(&t);

    char day=tm.tm_mday;
    char month = tm.tm_mon+1;
    short year = tm.tm_year+1900;

    arr[0] = day/10 + '0';
    arr[1] = day%10 + '0';

    arr[2] = '/';
    arr[3] = month/10 + '0';
    arr[4] = month%10 + '0';

    arr[5] = '/';
    arr[6] = year/1000 + '0';
    arr[7] = (year/100)%10 + '0';
    arr[8] = (year/10)%10 + '0';
    arr[9] = year % 10 + '0';
    arr[10]=0;

}

 static char LuhnCheck(uint8_t*arr)
{
    int sum=0;
    int prod=1;
    int rem;
    int t;
    for(int i=0;arr[i];i++)
    {
        if(i % 2!=0)
        {
            prod=(arr[i]-'0')*2;
            if(prod >9)
            {
                rem=prod%10;
                t=prod/10;
                sum=sum+rem+t;
            }
            else
            {
                sum=sum+prod;
            }
        }
        else
        {
            sum=sum+(arr[i]-'0');
        }
    }
    //printf("\nsum : %d",sum);
    if (sum%10)
    {
        return 1;
    }
    else{
        return 0;
    }
}

EN_terminalError_t getTransactionDate(ST_terminalData_t *termData) /// format DD/MM/YYYY, e.g 25/06/2022.  ???
{

    EN_terminalError_t state=OK_T;
    real_time_str(termData->transactionDate);

    if (termData->transactionDate == NULL || strlen((const char*)(termData->transactionDate))!= 10)
    {
        state=WRONG_DATE;
    }
    else
    {
        if(termData->transactionDate[2] != '/' || termData->transactionDate[5] != '/')
        {
            state=WRONG_DATE;
        }
    }
    return state;
}

EN_terminalError_t isCardExpired(ST_cardData_t *cardData, ST_terminalData_t *termData)
{

    EN_terminalError_t state;
    char month = (((termData->transactionDate[3])-'0')*10) + (termData->transactionDate[4]-'0');
    short year = (((termData->transactionDate[6])-'0')*1000) + ((termData->transactionDate[7]-'0')*100)+((termData->transactionDate[8]-'0')*10)+(termData->transactionDate[9]-'0');

    char ex_month = (((cardData->cardExpirationDate[0])-'0')*10) + (cardData->cardExpirationDate[1]-'0');
    short ex_year = (((cardData->cardExpirationDate[3])-'0')*10) + (cardData->cardExpirationDate[4]-'0');

    if((year-2000) > ex_year )
    {
        state = EXPIRED_CARD;
    }
    else if((year-2000) == ex_year && month >ex_month)
    {
        state = EXPIRED_CARD;
    }
    else
    {
        state = OK_T;
    }
    return state;
}

EN_terminalError_t getTransactionAmount(ST_terminalData_t *termData)
{
    EN_terminalError_t state= OK_T;
    printf("\nYour  Max  Trans Amount : %.2f",max_amount);
    printf("\nEnter your Trans Amount : ");
    scanf("%f",&(termData->transAmount));
    if(termData->transAmount <= 0)
    {
        state = INVALID_AMOUNT;
    }
    return state;
}
EN_terminalError_t isBelowMaxAmount(ST_terminalData_t *termData)
{
    EN_terminalError_t state = OK_T;

    if(termData->transAmount > termData->maxTransAmount )
    {
        state = EXCEED_MAX_AMOUNT;
    }
    return state;
}
EN_terminalError_t setMaxAmount(ST_terminalData_t *termData)
{
    float data=max_amount;
    EN_terminalError_t state = OK_T;
    if(data <= 0)
    {
        state = INVALID_MAX_AMOUNT;
    }
    else
    {
        termData->maxTransAmount = data;
        state = OK_T;
    }
    return state;
}

EN_terminalError_t isValidCardPAN(ST_cardData_t *cardData)
{
  char state;
  state=LuhnCheck(cardData->primaryAccountNumber);
  if(state==0)
  {
      return OK_T;
  }
  else
  {
      return INVALID_CARD;
  }
}

