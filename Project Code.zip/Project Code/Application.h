
#ifndef __APPLICATION_H_
#define __APPLICATION_H_

#include <stdio.h>

#include "StdTypes.h"
#include "Servers.h"
#include "Helping_file.h"

void appStart(void);

#endif // __APPLICATION_H_

