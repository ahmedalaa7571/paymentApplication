
#include <stdio.h>
#include "Servers.h"
#include "Helping_file.h"
#include <string.h>

ST_accountsDB_t ServerAccounts[255]={{2000.0  , RUNNING, "799273987130202060"},  //APPROVED
                                     {1600.50 , RUNNING, "799273987130000000"},  //EXCEED MAX AMOUNT
                                     {000.0   , RUNNING, "799273987130602020"},  //INSUFFICIENT FUND
                                     {100000.0, RUNNING, "729973987130602020"},  //EXPIRED
                                     {15000.0 , BLOCKED, "799273789130602020"},  //INVALID
                                     {7000.0  , RUNNING, "799372987031602021"},  //INVALID
                                     {00.0    , RUNNING, "997273987130602020"},
                                     {100000.0, BLOCKED, "797293987130602020"},
                                     {1000.0  , RUNNING, "799273789130602020"},
                                     {800.0   , BLOCKED, "799273983170602020"}
                                     };
ST_transaction_t serverTransactions[255]={0};  //ST_cardData_t cardHolderData, ST_terminalData_t terminalData , EN_transState_t transState ,uint32_t transactionSequenceNumber

static uint8_t server_trans_index=0;
static uint8_t index=0;  // SERVER ACCOUNTS INDEX


EN_transState_t recieveTransactionData(ST_transaction_t *transData)
{
 /*
 If the account does not exist return DECLINED_STOLEN_CARD,             --> check
 if the amount is not available will return DECLINED_INSUFFECIENT_FUND, --> check
 if a transaction can't be saved will return INTERNAL_SERVER_ERROR and will not save the transaction,
 else returns APPROVED.
  */
  EN_transState_t status = APPROVED;
  if(isValidAccount(&transData->cardHolderData))
  {
      printf("\t\tFRAUD CARD\n");
      status = FRAUD_CARD ;
  }
  else
  {
      uint8_t check= datasearch(&transData->cardHolderData.primaryAccountNumber);
      index = check-1;
      if(ServerAccounts[index].state==BLOCKED)
      {
          printf("\tDECLINED_STOLEN_CARD\n");
          status = DECLINED_STOLEN_CARD;
      }
      else if(isAmountAvailable(&transData->terminalData))
      {
          status = DECLINED_INSUFFECIENT_FUND;
      }
      else if(saveTransaction(transData))
      {
          status = INTERNAL_SERVER_ERROR;
      }
  }
  transData->transState=status;
  return status;
}
EN_serverError_t isValidAccount(ST_cardData_t *cardData)
{
  uint8_t check= datasearch(cardData->primaryAccountNumber);
  if(!check)
  {
      return ACCOUNT_NOT_FOUND;
  }
  if(isValidCardPAN(cardData))
  {
      return ACCOUNT_NOT_FOUND;
  }
  return SERVER_OK;
}
EN_serverError_t isAmountAvailable(ST_terminalData_t *termData)
{
    printf("your Balance = %.2f\n",ServerAccounts[index].balance);
    if(termData->transAmount > ServerAccounts[index].balance)
      {
          return DECLINED_INSUFFECIENT_FUND;
      }
    ServerAccounts[index].balance=ServerAccounts[index].balance - termData->transAmount;
    printf("your TransAmount = %.2f\n",termData->transAmount);
    printf("your New Balance = %.2f\n",ServerAccounts[index].balance);
    printf("-------------------------------------------------------------------\n");
    return SERVER_OK;
}

EN_serverError_t saveTransaction(ST_transaction_t *transData)
{
   if(server_trans_index>=255)
   {
      printf("SAVING_FAILED\n");
      return SAVING_FAILED;
   }
   else
   {
     transData->transactionSequenceNumber=seq_generator();
     serverTransactions[server_trans_index].transactionSequenceNumber=transData->transactionSequenceNumber;
     serverTransactions[server_trans_index].cardHolderData=transData->cardHolderData;
     serverTransactions[server_trans_index].terminalData=transData->terminalData;
     serverTransactions[server_trans_index].transState=ServerAccounts[index].state;
     server_trans_index++;
   }
   return SERVER_OK;
}
EN_serverError_t getTransaction(uint32_t transactionSequenceNumber, ST_transaction_t *transData)
{
    uint8_t begin=0,end=255-1,mid=0;
    while(begin<end)
    {
        mid=(begin+end)/2;

        if(serverTransactions[mid].transactionSequenceNumber==transactionSequenceNumber)
        {
            return SERVER_OK;
        }
        else if(serverTransactions[mid].transactionSequenceNumber>transactionSequenceNumber)
        {
            begin=mid+1;
        }
        else
        {
            end=mid-1;
        }
    }
    return TRANSACTION_NOT_FOUND;
}
