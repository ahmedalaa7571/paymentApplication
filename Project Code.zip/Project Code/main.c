#include <stdio.h>

#include "Application.h"
#include<time.h>


int main(void)
{
    char de='y';
    static int i=0;
    while(i<6)
    {
        if(de == 'y')
        {
            appStart();
            printf("\n================================================================================\n\n\n\n\n");
            de=0;
        }
        else if(de == 'n')
        {
            break;
        }
        else
        {
          printf("YOU WANT ANOTHER OPERATION ?? ACCOUNT : Y/N --> ");
          scanf("%s",&de);
          printf("\n================================================================================\n");
          i++;
        }

    }
    return 0;
}

